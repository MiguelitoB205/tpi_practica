package com.example.practica_uno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
